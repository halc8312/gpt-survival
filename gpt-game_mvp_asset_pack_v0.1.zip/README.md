# gpt-game MVP Asset Pack v0.1

Generated: 2026-04-24T05:44:55+00:00

This pack contains prototype transparent PNG image assets for **星屑コロニー / Stardust Colony**.

## Contents

- Terrain tiles
- Resource nodes
- Buildings
- Item icons
- Survivor unit sprites
- Drone sprites
- Creature sprites
- UI status/warning/event icons
- Effect sprites
- Asset manifest
- Asset status file
- Preview images

## Folder Structure

```txt
assets/
  images/
    tiles/
    resources/
    buildings/
    items/
    units/
    drones/
    creatures/
    ui/
    effects/
  manifests/
    asset_manifest_mvp_v0.1.json
    asset_status_mvp_v0.1.json

docs/
  previews/
```

## Counts

```json
{
  "building": 20,
  "creature": 4,
  "drone": 2,
  "effect": 10,
  "item": 30,
  "resource": 8,
  "tile": 12,
  "ui_event": 10,
  "ui_status": 10,
  "ui_warning": 8,
  "unit": 5
}
```

Total assets: 119

## Notes

These are **prototype implementation assets**, not final polished art.
Use them to verify:
- map readability
- scale
- UI visibility
- item/category distinction
- Codex implementation paths
- asset loading pipeline

After in-game review, update `asset_status_mvp_v0.1.json`.
