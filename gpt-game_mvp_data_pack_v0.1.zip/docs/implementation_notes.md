# Implementation Notes for Codex

## Design Intent

This data pack contains game design data, not engine logic.

The engine should not hard-code item, building, recipe, or research IDs except for bootstrapping.
Use these JSON files as source-of-truth.

## Important Relationships

- `recipes[].buildingId` must exist in `buildings.json`.
- Recipe inputs and outputs must exist in `items.json`.
- Building build costs must exist in `items.json`.
- Building unlocks should reference research IDs.
- Research unlocks may reference buildings and recipes.
- Resource drops must reference item IDs.
- Event creature spawns must reference creature IDs.

## MVP Starter Research

`research_basic_survival` is marked as `starter` and should be completed at game start.

## Starter Inventory Suggestion

A reasonable initial inventory:

```json
{
  "scrap_metal": 80,
  "stone": 40,
  "raw_food": 12,
  "dirty_water": 12,
  "plant_fiber": 20,
  "basic_circuit": 4,
  "battery_cell": 2,
  "data_chip": 1,
  "research_data": 20
}
```

## Initial Buildings

Place `building_crash_core` at map center.

## Initial Units

Spawn all five survivor templates and two `drone_logistics_mk1` instances near the crash core.
