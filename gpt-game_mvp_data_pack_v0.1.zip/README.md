# gpt-game MVP Data Pack v0.1

Generated: 2026-04-24T05:53:58+00:00

This ZIP contains JSON data files for the MVP of **星屑コロニー / Stardust Colony**.

It is designed to pair with:

- `gpt-game_mvp_asset_pack_v0.1.zip`

## Folder Structure

```txt
assets/data/
  core/
    game_config.json
    constants.json
    save_schema.json

  world/
    tiles.json
    biomes.json
    decorations.json
    resources.json
    map_generation.json

  gameplay/
    items.json
    buildings.json
    recipes.json
    research.json
    events.json

  units/
    survivors.json
    drones.json
    creatures.json

  ui/
    ui_text.json
    tooltips.json
    tutorials.json

  balance/
    difficulty_normal.json
    progression_mvp.json

assets/manifests/
  data_manifest_mvp_v0.1.json
  data_validation_report_v0.1.json
```

## Counts

```json
{
  "items": 30,
  "resources": 8,
  "buildings": 20,
  "recipes": 36,
  "research": 20,
  "events": 10,
  "survivors": 5,
  "drones": 2,
  "creatures": 4,
  "tiles": 12,
  "decorations": 12
}
```

## Validation

```json
{
  "valid": true,
  "errors": [],
  "warnings": []
}
```

## Codex Usage

Recommended first implementation steps:

1. Load all JSON files from `assets/data`.
2. Validate IDs using `data_manifest_mvp_v0.1.json`.
3. Load images using the corresponding paths in each data file.
4. Create a `DataRegistry` keyed by `id`.
5. Implement MVP loop in this order:
   - map display
   - resource nodes
   - inventory
   - buildings
   - recipes
   - power
   - research
   - save/load
